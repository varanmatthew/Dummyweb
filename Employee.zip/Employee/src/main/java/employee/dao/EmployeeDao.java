package employee.dao;

import java.util.List;

import com.Employee.model.Employee; 

public interface EmployeeDao {
	
	public void addEmployee(Employee employee);
	
	public List<Employee> listEmployes();
	
	public Employee getEmployee(int empid);
	
	public void deletedEmployee(Employee employee);
	
	

}
