package employee.service;

import java.util.List;

import com.employee.model.Employee;

public interface EmployeeService {
 
	public void addEmployee(Employee employee);
	 
	public List<Emplyee> listEmployees();
	
	public Employee getEmployee(int empid);
	
	public void deletedEmplyee(Employee employee);
}
